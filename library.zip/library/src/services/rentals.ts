import { Request, Response } from 'express';
import { getStore, updateStore } from '../types/store';
import { Rental } from '../types/book';
import { NotFoundError, BadRequestError } from '../utils/errors';

export const getUserBooks = (req: Request, res: Response) => {
  const { userId } = req.params;
  const { rentals, books } = getStore();
  
  const userRentals = rentals.filter(
    r => r.userId === userId && !r.returnDate
  );
  
  const rentedBooks = userRentals.map(rental => {
    const book = books.find(b => b.isbn === rental.bookId);
    return {
      ...rental,
      bookDetails: book ? {
        title: book.title,
        author: book.author,
        isbn: book.isbn,
      } : null,
    };
  });
  
  res.json(rentedBooks);
};

export const returnBook = (req: Request, res: Response) => {
  const { rentalId } = req.params;
  const store = getStore();
  
  const rentalIndex = store.rentals.findIndex(
    r => r.rentalId === rentalId && !r.returnDate
  );
  
  if (rentalIndex === -1) {
    throw new NotFoundError('Rental not found or already returned');
  }
  
  // Update rental
  const updatedRentals = [...store.rentals];
  updatedRentals[rentalIndex] = {
    ...updatedRentals[rentalIndex],
    returnDate: new Date(),
  };
  
  // Update book availability
  const bookId = updatedRentals[rentalIndex].bookId;
  const updatedBooks = store.books.map(b => 
    b.isbn === bookId ? { ...b, availableCopies: b.availableCopies + 1 } : b
  );
  
  // Update store
  updateStore({
    books: updatedBooks,
    rentals: updatedRentals,
  });
  
  res.json({
    message: 'Book returned successfully',
    rentalId,
    bookId,
  });
};