import { Book, Rental, books, rentals } from '../data';

export const getAllBooks = (req, res) => {
  res.json(books.map(book => ({
    ...book,
    available: book.totalCopies - (rentals.filter(r => 
      r.bookId === book.id && !r.returnDate
    ).length)
  })));
};

export const getBookDetails = (req, res) => {
  const book = books.find(b => b.id === req.params.id);
  if (!book) return res.status(404).json({ error: 'Book not found' });
  res.json(book);
};

export const rentBook = (req, res) => {
  const { id } = req.params;
  const { userId } = req.body;
  
  const book = books.find(b => b.id === id);
  if (!book) return res.status(404).json({ error: 'Book not found' });
  
  const available = book.totalCopies - rentals.filter(r => 
    r.bookId === id && !r.returnDate
  ).length;
  
  if (available <= 0) {
    return res.status(400).json({ error: 'No copies available' });
  }
  
  const rental: Rental = {
    id: `rent-${Date.now()}`,
    bookId: id,
    userId,
    rentDate: new Date().toISOString(),
    returnDate: null
  };
  
  rentals.push(rental);
  res.status(201).json(rental);
};

export const getUserRentals = (req, res) => {
  const userRentals = rentals.filter(r => 
    r.userId === req.params.userId && !r.returnDate
  );
  
  res.json(userRentals.map(rental => ({
    ...rental,
    book: books.find(b => b.id === rental.bookId)
  })));
};

export const returnBook = (req, res) => {
  const rental = rentals.find(r => 
    r.id === req.params.rentalId && !r.returnDate
  );
  
  if (!rental) {
    return res.status(404).json({ error: 'Rental not found' });
  }
  
  rental.returnDate = new Date().toISOString();
  res.json({ message: 'Book returned successfully' });
};