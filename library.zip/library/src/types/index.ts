export interface Book {
  id: string;
  title: string;
  author: string;
  publishedYear: number;
  totalCopies: number;
  description: string;
}

export interface Rental {
  id: string;
  bookId: string;
  userId: string;
  rentDate: string;
  returnDate: string | null;
}

// In-memory storage
export const books: Book[] = [
  {
    id: '1',
    title: '1984',
    author: 'George Orwell',
    publishedYear: 1949,
    totalCopies: 3,
    description: 'Dystopian novel about totalitarianism'
  },
  // Add other books...
];

export const rentals: Rental[] = [];

export function initializeData() {
  // Could load from JSON file here if needed
  console.log('Data initialized');
}