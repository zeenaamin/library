export interface Book {
  isbn: string;
  title: string;
  author: string;
  publishedYear: number;
  totalCopies: number;
  availableCopies: number;
  description: string;
}

export interface Rental {
  rentalId: string;
  bookId: string;
  userId: string;
  rentDate: Date;
  returnDate: Date | null;
}