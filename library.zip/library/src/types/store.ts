import { Book, Rental } from './book';
import sampleData from '../data/books.json';

interface Store {
  books: Book[];
  rentals: Rental[];
}

let store: Store = {
  books: [],
  rentals: [],
};

export function initializeStore() {
  store.books = sampleData.books.map(book => ({
    ...book,
    availableCopies: book.totalCopies,
  }));
}

export function getStore(): Store {
  return store;
}

export function updateStore(updatedStore: Store): void {
  store = updatedStore;
}